package com.example.dttracker.data.model

enum class CardColor { RED, BLACK }
enum class GameChoice { DRAGON, TIGER }
enum class GameResult { DRAGON, TIGER, TIE }
